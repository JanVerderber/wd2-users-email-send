# About

GAE boilerplate for SmartNinja **Web development 2** course.

# Usage

1. Click on Download ZIP
2. Save on your disk and unzip
3. Change the application ID in app.yaml
4. Build something nice ;)
